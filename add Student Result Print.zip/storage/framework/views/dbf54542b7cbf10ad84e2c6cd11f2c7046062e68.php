<form action="<?php echo e($action); ?>" method="post" novalidate>
    <?php echo csrf_field(); ?>
    <?php if($method !== null): ?> <?php echo method_field($method); ?> <?php endif; ?>
    <?php echo e($slot); ?>

</form>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/components/form.blade.php ENDPATH**/ ?>