<?php $__env->startSection('title', 'Tambah Nilai Baru'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Nilai</a></li>
                    <li class="breadcrumb-item active">Tambah Nilai Baru</li>
                </ol>
            </div>
            <h4 class="page-title">
                <span class="text-light bg-info rounded px-3 py-1">Tambah Nilai Baru</span>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                 <?php if (isset($component)) { $__componentOriginal65829f5b506044227b4d1a3d09050c8894be2bcf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LessonValue\LessonValueForm::class, []); ?>
<?php $component->withName('lesson-value.lesson-value-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal65829f5b506044227b4d1a3d09050c8894be2bcf)): ?>
<?php $component = $__componentOriginal65829f5b506044227b4d1a3d09050c8894be2bcf; ?>
<?php unset($__componentOriginal65829f5b506044227b4d1a3d09050c8894be2bcf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/lesson-value/create.blade.php ENDPATH**/ ?>