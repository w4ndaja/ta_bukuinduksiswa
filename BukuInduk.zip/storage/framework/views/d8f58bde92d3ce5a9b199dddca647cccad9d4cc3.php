<a href="<?php echo e(route('home')); ?>" class="logo text-center">
    <span class="logo-lg">
        <img src="<?php echo e(asset('assets/images/smp_logo.png')); ?>" alt="" height="48" id="side-main-logo"> <span class="text-white h5 mx-1 text-uppercase"><?php echo e(config('school-identity.name')); ?></span>
    </span>
    <span class="logo-sm">
        <img src="<?php echo e(asset('assets/images/logo_sm.png')); ?>" alt="" height="48" id="side-sm-main-logo">
    </span>
</a>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/components/side-bar-logo.blade.php ENDPATH**/ ?>