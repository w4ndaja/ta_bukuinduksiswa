<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/smp_logo.png')); ?>">

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />

</head>


<body>
    <!-- Pre-loader -->
    
    <!-- End Preloader-->
    <!-- Begin page -->
    <div class="wrapper">
        <!-- ========== Left Sidebar Start ========== -->
        <div class="left-side-menu">

            <div class="h-100" id="left-side-menu-container" data-simplebar>
                <!-- LOGO -->
                 <?php if (isset($component)) { $__componentOriginal62ddc7e87c2ed043bf7d5081cf7196cecbd8e34a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarLogo::class, []); ?>
<?php $component->withName('side-bar-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal62ddc7e87c2ed043bf7d5081cf7196cecbd8e34a)): ?>
<?php $component = $__componentOriginal62ddc7e87c2ed043bf7d5081cf7196cecbd8e34a; ?>
<?php unset($__componentOriginal62ddc7e87c2ed043bf7d5081cf7196cecbd8e34a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($component)) { $__componentOriginale47f40099c86fea5864fd2233ee8f4e20e104e1e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBar::class, []); ?>
<?php $component->withName('side-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale47f40099c86fea5864fd2233ee8f4e20e104e1e)): ?>
<?php $component = $__componentOriginale47f40099c86fea5864fd2233ee8f4e20e104e1e; ?>
<?php unset($__componentOriginale47f40099c86fea5864fd2233ee8f4e20e104e1e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <!-- End Sidebar -->
                <div class="clearfix"></div>
            </div>
            <!-- Sidebar -left -->
        </div>
        <!-- Left Sidebar End -->
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">
                 <?php if (isset($component)) { $__componentOriginal7c8aae1bf9be6220308e251b49f0cfbdf09be43d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TopBar::class, []); ?>
<?php $component->withName('top-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal7c8aae1bf9be6220308e251b49f0cfbdf09be43d)): ?>
<?php $component = $__componentOriginal7c8aae1bf9be6220308e251b49f0cfbdf09be43d; ?>
<?php unset($__componentOriginal7c8aae1bf9be6220308e251b49f0cfbdf09be43d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                <!-- Start Content-->
                <div class="container-fluid">
                     <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['name' => 'success','type' => 'success']); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php echo $__env->yieldContent('content'); ?>
                </div> <!-- container -->

            </div> <!-- content -->

            <?php echo $__env->make('partials.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->


    </div>
    <!-- END wrapper -->


    <!-- bundle -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/layouts/app.blade.php ENDPATH**/ ?>