<?php $__env->startSection('title', $student->nis.' - '.$student->name); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('students.index')); ?>">Siswa</a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e($student->nis); ?> - <?php echo e($student->name); ?></a></li>
                    <li class="breadcrumb-item active">Print</li>
                </ol>
            </div>
            <h4 class="page-title">
                <button class="btn btn-icon btn-info" onclick="window.print()"><i class="uil-print text-lg h3 m-1"></i> PRINT</button>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body h2 text-center">DATA NILAI SISWA <?php echo e($student->nis); ?> - <?php echo e($student->name); ?></div>
        </div>
        <div class="card">
            <?php $__currentLoopData = $student->lessonResults->sortBy('semester')->sortBy('subject_id')->groupBy('semester'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-header h4">Semester <?php echo e($semester); ?></div>
            <div class="card-body">
                <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group row m-0 p-0">
                    <label class="col-4 text-capitalize"><?php echo e($value->subject->name); ?></label>
                    <span class="col">: <?php echo e($value->value); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/student/lesson-result-print.blade.php ENDPATH**/ ?>