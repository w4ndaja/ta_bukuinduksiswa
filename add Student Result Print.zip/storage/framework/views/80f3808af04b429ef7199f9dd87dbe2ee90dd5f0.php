<?php $__env->startSection('title', 'Identitas Sekolah'); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item active">Identitas Sekolah</li>
                </ol>
            </div>
            <h4 class="page-title"><span class="text-white bg-info rounded px-3 py-1">Identitas Sekolah</span></h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-header">Pengaturan</div>
            <div class="card-body">
                 <?php if (isset($component)) { $__componentOriginalbdd6f3dd02ba8a6bf7f39a0ed8e4b613b4752507 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SchoolIdentityForm::class, []); ?>
<?php $component->withName('school-identity-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalbdd6f3dd02ba8a6bf7f39a0ed8e4b613b4752507)): ?>
<?php $component = $__componentOriginalbdd6f3dd02ba8a6bf7f39a0ed8e4b613b4752507; ?>
<?php unset($__componentOriginalbdd6f3dd02ba8a6bf7f39a0ed8e4b613b4752507); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
</div>

</div>
<!-- end page title -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/school-identity/index.blade.php ENDPATH**/ ?>