<?php $__env->startSection('title', 'Tambah Guru Baru'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Guru</a></li>
                    <li class="breadcrumb-item active">Tambah Guru Baru</li>
                </ol>
            </div>
            <h4 class="page-title">
                <span class="text-light bg-info rounded px-3 py-1">Tambah Guru Baru</span>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                 <?php if (isset($component)) { $__componentOriginal9b67a38724130bc714ee68c01613edd1a841f6c0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Teacher\TeacherForm::class, []); ?>
<?php $component->withName('teacher.teacher-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9b67a38724130bc714ee68c01613edd1a841f6c0)): ?>
<?php $component = $__componentOriginal9b67a38724130bc714ee68c01613edd1a841f6c0; ?>
<?php unset($__componentOriginal9b67a38724130bc714ee68c01613edd1a841f6c0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/teacher/create.blade.php ENDPATH**/ ?>