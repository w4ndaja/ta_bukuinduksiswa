<?php $__env->startSection('title', 'Tambah Kelas Baru'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Kelas</a></li>
                    <li class="breadcrumb-item active">Tambah Kelas Baru</li>
                </ol>
            </div>
            <h4 class="page-title">
                <span class="text-light bg-info rounded px-3 py-1">Tambah Kelas Baru</span>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                 <?php if (isset($component)) { $__componentOriginal4212f318c76b192c2ee34ba6c20a6d2cd5c5a6b0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Grade\GradeForm::class, []); ?>
<?php $component->withName('grade.grade-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal4212f318c76b192c2ee34ba6c20a6d2cd5c5a6b0)): ?>
<?php $component = $__componentOriginal4212f318c76b192c2ee34ba6c20a6d2cd5c5a6b0; ?>
<?php unset($__componentOriginal4212f318c76b192c2ee34ba6c20a6d2cd5c5a6b0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/grade/create.blade.php ENDPATH**/ ?>