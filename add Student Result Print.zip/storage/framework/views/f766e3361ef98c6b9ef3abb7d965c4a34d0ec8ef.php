<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo e(now()->format('Y')); ?> © <?php echo e(config('school-identity.name')); ?>

            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-md-block">
                    
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/partials/layouts/footer.blade.php ENDPATH**/ ?>