<?php if(session($name)): ?>
<div class="alert alert-<?php echo e($type); ?> alert-dismissible bg-<?php echo e($type); ?> text-white border-0 fade show mt-3" role="alert" id="alert-<?php echo e($id = rand(111,999)); ?>">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <?php echo e($message ?? session($name)); ?>

    <?php echo e($slot); ?>

</div>
<script>
    setTimeout(() => {
        $('#alert-<?php echo e($id); ?>').slideUp();
    }, 2000);
</script>
<?php endif; ?>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/components/alert.blade.php ENDPATH**/ ?>