<?php $__env->startSection('title', $student->nis.' - '.$student->name); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('students.index')); ?>">Siswa</a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e($student->nis); ?> - <?php echo e($student->name); ?></a></li>
                    <li class="breadcrumb-item active">Print</li>
                </ol>
            </div>
            <h4 class="page-title">
                <button class="btn btn-icon btn-info" onclick="window.print()"><i class="uil-print text-lg h3 m-1"></i> PRINT</button>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body h2 text-center">DATA SISWA <?php echo e($student->nis); ?> - <?php echo e($student->name); ?></div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-header h4">I. IDENTITAS</div>
                    <div class="card-body">
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.grade_id'); ?></label>
                            <span class="col">: <?php echo e($student->grade->code); ?> - <?php echo e($student->grade->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.nis'); ?></label>
                            <span class="col">: <?php echo e($student->nis); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.name'); ?></label>
                            <span class="col">: <?php echo e($student->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.gender'); ?></label>
                            <span class="col">: <?php echo e($student->gender); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_place'); ?></label>
                            <span class="col">: <?php echo e($student->birth_place); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_date'); ?></label>
                            <span class="col">: <?php echo e($student->birth_date); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.religion'); ?></label>
                            <span class="col">: <?php echo e($student->religion); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.citizenship'); ?></label>
                            <span class="col">: <?php echo e($student->citizenship); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.fam_order'); ?></label>
                            <span class="col">: <?php echo e($student->fam_order); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.fam_count'); ?></label>
                            <span class="col">: <?php echo e($student->fam_count); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.fam_status'); ?></label>
                            <span class="col">: <?php echo e($student->fam_status); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.language'); ?></label>
                            <span class="col">: <?php echo e($student->language); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.address'); ?></label>
                            <span class="col">: <?php echo e($student->address); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.phone'); ?></label>
                            <span class="col">: <?php echo e($student->phone); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.live_with'); ?></label>
                            <span class="col">: <?php echo e($student->live_with); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.residence_distance'); ?></label>
                            <span class="col">: <?php echo e($student->residence_distance); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.blood_type'); ?></label>
                            <span class="col">: <?php echo e($student->blood_type); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.sick_history'); ?></label>
                            <span class="col">: <?php echo e($student->sick_history); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.height'); ?></label>
                            <span class="col">: <?php echo e($student->height); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.weight'); ?></label>
                            <span class="col">: <?php echo e($student->weight); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.graduate_from'); ?></label>
                            <span class="col">: <?php echo e($student->graduate_from); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.ijazah_year'); ?></label>
                            <span class="col">: <?php echo e($student->ijazah_year); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.ijazah_sd_no'); ?></label>
                            <span class="col">: <?php echo e($student->ijazah_sd_no); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.skhu_no'); ?></label>
                            <span class="col">: <?php echo e($student->skhu_no); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.move_from'); ?></label>
                            <span class="col">: <?php echo e($student->move_from); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.receive_at_grade_id'); ?></label>
                            <span class="col">: <?php echo e($student->receiveAtGrade->code); ?> - <?php echo e($student->receiveAtGrade->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.date_received'); ?></label>
                            <span class="col">: <?php echo e($student->date_received); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.hobby'); ?></label>
                            <span class="col">: <?php echo e($student->hobby); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.leave_reason'); ?></label>
                            <span class="col">: <?php echo e($student->leave_reason); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.finished_studying_at'); ?></label>
                            <span class="col">: <?php echo e($student->finished_studying_at); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.ijazah_now_no'); ?></label>
                            <span class="col">: <?php echo e($student->ijazah_now_no); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.skhu_now_no'); ?></label>
                            <span class="col">: <?php echo e($student->skhu_now_no); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <?php if($student->father): ?>
                <div class="card">
                    <div class="card-header h4">II. AYAH</div>
                    <div class="card-body">
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.name'); ?></label>
                            <span class="col">: <?php echo e($student->father->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_place'); ?></label>
                            <span class="col">: <?php echo e($student->father->birth_place); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_date'); ?></label>
                            <span class="col">: <?php echo e($student->father->birth_date); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.religion'); ?></label>
                            <span class="col">: <?php echo e($student->father->religion); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.citizenship'); ?></label>
                            <span class="col">: <?php echo e($student->father->citizenship); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.education'); ?></label>
                            <span class="col">: <?php echo e($student->father->education); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.work'); ?></label>
                            <span class="col">: <?php echo e($student->father->work); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.monthly_income'); ?></label>
                            <span class="col">: <?php echo e($student->father->monthly_income); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.address'); ?></label>
                            <span class="col">: <?php echo e($student->father->address); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.phone'); ?></label>
                            <span class="col">: <?php echo e($student->father->phone); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.died_at'); ?></label>
                            <span class="col">: <?php echo e($student->father->died_at); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($student->mother): ?>
                <div class="card">
                    <div class="card-header h4">III. IBU</div>
                    <div class="card-body">
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.name'); ?></label>
                            <span class="col">: <?php echo e($student->mother->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_place'); ?></label>
                            <span class="col">: <?php echo e($student->mother->birth_place); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_date'); ?></label>
                            <span class="col">: <?php echo e($student->mother->birth_date); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.religion'); ?></label>
                            <span class="col">: <?php echo e($student->mother->religion); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.citizenship'); ?></label>
                            <span class="col">: <?php echo e($student->mother->citizenship); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.education'); ?></label>
                            <span class="col">: <?php echo e($student->mother->education); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.work'); ?></label>
                            <span class="col">: <?php echo e($student->mother->work); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.monthly_income'); ?></label>
                            <span class="col">: <?php echo e($student->mother->monthly_income); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.address'); ?></label>
                            <span class="col">: <?php echo e($student->mother->address); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.phone'); ?></label>
                            <span class="col">: <?php echo e($student->mother->phone); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.died_at'); ?></label>
                            <span class="col">: <?php echo e($student->mother->died_at); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php if($student->guardian): ?>
            <div class="col-12">
                <div class="card">
                    <div class="card-header h4">IV. WALI</div>
                    <div class="card-body">
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.name'); ?></label>
                            <span class="col">: <?php echo e($student->guardian->name); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_place'); ?></label>
                            <span class="col">: <?php echo e($student->guardian->birth_place); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.birth_date'); ?></label>
                            <span class="col">: <?php echo e($student->guardian->birth_date); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.religion'); ?></label>
                            <span class="col">: <?php echo e($student->guardian->religion); ?></span>
                        </div>
                        <div class="form-group row m-0 p-0">
                            <label class="col-6 text-capitalize"><?php echo app('translator')->get('validation.attributes.citizenship'); ?></label>
                            <span class="col">: <?php echo e($student->guardian->citizenship); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/student/print.blade.php ENDPATH**/ ?>