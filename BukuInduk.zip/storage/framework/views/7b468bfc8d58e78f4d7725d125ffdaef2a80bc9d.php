<?php $__env->startSection('title', 'Table Data Kelas'); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Kelas</a></li>
                    <li class="breadcrumb-item active">Tabel Data Kelas</li>
                </ol>
            </div>
            <h4 class="page-title">
                <span class="bg-info text-light px-3 py-1 rounded">Table Data Kelas</span>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div>
                    <a href="<?php echo e(route('grades.create')); ?>" class="btn btn-primary">Tambah Kelas</a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive shadow-sm">
                    <table class="table table-sm table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th class="text-nowrap text-capitalize">No</th>
                                <th class="text-nowrap text-capitalize"><?php echo app('translator')->get('validation.attributes.code'); ?></th>
                                <th class="text-nowrap text-capitalize"><?php echo app('translator')->get('validation.attributes.name'); ?></th>
                                <th class="text-nowrap text-capitalize"><?php echo app('translator')->get('validation.attributes.parallel'); ?></th>
                                <th class="text-nowrap text-capitalize"><?php echo app('translator')->get('validation.attributes.form_teacher_id'); ?></th>
                                <th class="text-nowrap text-capitalize">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-nowrap><?php echo e($key + 1); ?></td>
                                <td class="text-wrap "><?php echo e($grade->code); ?></td>
                                <td class="text-wrap "><?php echo e($grade->name); ?></td>
                                <td class="text-wrap "><?php echo e($grade->parallel); ?></td>
                                <td class="text-wrap "><?php echo e($grade->formTeacher->code); ?> - <?php echo e($grade->formTeacher->name); ?></td>
                                <td class="text-wrap  d-flex flex-row">
                                    <a href="<?php echo e(route('grades.edit', $grade->id)); ?>" class="btn btn-sm mr-1 btn-info">Edit</a>
                                    <a href="<?php echo e(route('grades.confirm-delete', $grade->id)); ?>" class="btn btn-sm mr-1 btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <?php echo e($grades->links()); ?>

            </div>
        </div>
    </div>
</div>

</div>
<!-- end page title -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/grade/table.blade.php ENDPATH**/ ?>