<?php $__env->startSection('title', 'Table Data Siswa Keluar'); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Siswa</a></li>
                    <li class="breadcrumb-item active">Tabel Data Siswa Keluar</li>
                </ol>
            </div>
            <h4 class="page-title">
                <span class="bg-danger text-light rounded py-1 px-3">Table Data Siswa Keluar</span>
            </h4>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive shadow-sm">
                    <table class="table table-sm table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th class="text-nowrap">NIS</th>
                                <th class="text-nowrap">Nama Siswa</th>
                                <th class="text-nowrap">Jenis Kelamin</th>
                                <th class="text-nowrap">Tempat Lahir</th>
                                <th class="text-nowrap">Tanggal Lahir</th>
                                <th class="text-nowrap">Alasan Keluar</th>
                                <th class="text-nowrap">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-nowrap"><?php echo e($student->nis); ?></td>
                                <td class="text-nowrap"><?php echo e($student->name); ?></td>
                                <td class="text-nowrap"><?php echo e($student->gender); ?></td>
                                <td class="text-nowrap"><?php echo e($student->birth_place); ?></td>
                                <td class="text-nowrap"><?php echo e($student->birth_date); ?></td>
                                <td class="text-nowrap"><?php echo e($student->dropOut->out_reason); ?></td>
                                <td class="text-nowrap d-flex flex-row">
                                    <a href="<?php echo e(route('students.confirm-drop-in', $student->id)); ?>" class="btn btn-success ml-1 btn-sm">Drop In</a>
                                    <a href="<?php echo e(route('students.print', $student->id)); ?>" class="btn btn-info ml-1 btn-sm">PRINT</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <?php echo e($students->links()); ?>

            </div>
        </div>
    </div>
</div>

</div>
<!-- end page title -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/pages/student/moved.blade.php ENDPATH**/ ?>