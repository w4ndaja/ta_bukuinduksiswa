<div class="custom-control custom-checkbox">
    <input type="checkbox" name="<?php echo e($name); ?>" class="custom-control-input" id="checkbox-<?php echo e($randID); ?>" <?php if($old ?? $checked): ?> checked <?php endif; ?>>
    <label class="custom-control-label <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" for="checkbox-<?php echo e($randID); ?>"><?php echo e($label); ?></label>
</div>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/components/checkbox.blade.php ENDPATH**/ ?>