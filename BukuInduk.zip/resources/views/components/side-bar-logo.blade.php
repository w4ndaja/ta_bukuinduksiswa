<a href="{{route('home')}}" class="logo text-center">
    <span class="logo-lg">
        <img src="{{asset('assets/images/smp_logo.png')}}" alt="" height="48" id="side-main-logo"> <span class="text-white h5 mx-1 text-uppercase">{{config('school-identity.name')}}</span>
    </span>
    <span class="logo-sm">
        <img src="{{asset('assets/images/logo_sm.png')}}" alt="" height="48" id="side-sm-main-logo">
    </span>
</a>
