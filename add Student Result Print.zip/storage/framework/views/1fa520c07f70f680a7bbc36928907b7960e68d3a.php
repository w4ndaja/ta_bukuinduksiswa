<?php $__env->startSection('title', 'Konfirmasi Keluarkan Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid d-flex justify-content-center py-5">
     <?php if (isset($component)) { $__componentOriginal0777dca6b0ab2eebdcaf6ba884d5b30ab61203a6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form::class, ['method' => 'delete','action' => ''.e(route('students.drop-out', $student->id)).'']); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="alert alert-warning" role="alert">
            <h4 class="alert-heading">Peringatan!</h4>
            <p>Apakah anda yakin ingin mengeluarkan siswa dengan nis = <?php echo e($student->nis); ?>, nama = <?php echo e($student->name); ?></p>
            <hr>
            <div class="form-group">
                 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'out_reason','placeholder' => 'Masukkan alasan keluar']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="<?php echo e(url()->previous()); ?>" type="submit" class="btn btn-info">Kembali</a>
            </div>
        </div>
     <?php if (isset($__componentOriginal0777dca6b0ab2eebdcaf6ba884d5b30ab61203a6)): ?>
<?php $component = $__componentOriginal0777dca6b0ab2eebdcaf6ba884d5b30ab61203a6; ?>
<?php unset($__componentOriginal0777dca6b0ab2eebdcaf6ba884d5b30ab61203a6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/partials/confirm-drop-out.blade.php ENDPATH**/ ?>