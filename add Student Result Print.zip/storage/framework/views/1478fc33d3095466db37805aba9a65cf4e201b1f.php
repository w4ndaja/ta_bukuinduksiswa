<!--- Sidemenu -->
<ul class="metismenu side-nav">

    <li class="side-nav-item">
        <a href="<?php echo e(route('home')); ?>" class="side-nav-link">
            <i class="uil-home-alt"></i>
            
            <span> Beranda </span>
        </a>
    </li>


    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-folder-plus"></i>
            <span> Siswa </span>
            <span class="menu-arrow"></span>
        </a>
        <ul class="side-nav-second-level" aria-expanded="false">
            <li class="side-nav-item">
                <a href="<?php echo e(route('students.index')); ?>" aria-expanded="false">Tabel Data Siswa Aktif</a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('students.moved')); ?>" aria-expanded="false">Tabel Data Siswa Keluar</a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('students.create')); ?>" aria-expanded="false">Tambah Siswa Baru </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('grades.index')); ?>" aria-expanded="false">Tabel Data Kelas </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('grades.create')); ?>" aria-expanded="false">Tambah Kelas Baru </a>
            </li>
        </ul>
    </li>
    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-folder-plus"></i>
            <span> Guru </span>
            <span class="menu-arrow"></span>
        </a>
        <ul class="side-nav-second-level" aria-expanded="false">
            <li class="side-nav-item">
                <a href="<?php echo e(route('teachers.index')); ?>" aria-expanded="false">Tabel Data Guru </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('teachers.create')); ?>" aria-expanded="false">Tambah Guru Baru </a>
            </li>
        </ul>
    </li>
    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-folder-plus"></i>
            <span> Nilai </span>
            <span class="menu-arrow"></span>
        </a>
        <ul class="side-nav-second-level" aria-expanded="false">
            <li class="side-nav-item">
                <a href="<?php echo e(route('lesson-values.index')); ?>" aria-expanded="false">Tabel Data Nilai </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('lesson-values.create')); ?>" aria-expanded="false">Tambah Nilai Baru </a>
            </li>
            
        </ul>
    </li>
    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-folder-plus"></i>
            <span> Mapel </span>
            <span class="menu-arrow"></span>
        </a>
        <ul class="side-nav-second-level" aria-expanded="false">
            <li class="side-nav-item">
                <a href="<?php echo e(route('subjects.index')); ?>" aria-expanded="false">Tabel Data Mapel </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('subjects.create')); ?>" aria-expanded="false">Tambah Mapel Baru </a>
            </li>
            
        </ul>
    </li>
    <li class="side-nav-item">
        <a href="<?php echo e(route('school-identity.index')); ?>" class="side-nav-link">
            <i class="uil-location-point"></i>
            
            <span> Identitas Sekolah </span>
        </a>
    </li>
</ul>
<?php /**PATH /Users/annasrusdiawandari/code/bukuinduk/resources/views/components/side-bar.blade.php ENDPATH**/ ?>